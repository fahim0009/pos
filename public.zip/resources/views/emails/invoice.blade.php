@component('mail::message')


<p>We have processed your vouchers, Please find your remittance report attached. Your funds will be sent in due course. 
Tevini</p>


Thanks,<br>

@endcomponent
