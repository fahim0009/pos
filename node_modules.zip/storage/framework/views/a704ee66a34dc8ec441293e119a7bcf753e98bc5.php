

<?php $__env->startSection('content'); ?>

    <!-- main wrapper -->
    <section class="main ">
        <div class="content-container">
            
            <div class="inner">
                <div class="content w-90 mx-auto">

                    <div class="row mx-auto"> 
                        <div class="box">
                            <p class="box-title">Manage Sales Invoice</p>
                            <table class="table table-striped table-hover" id="example"> 
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Product</th>
                                        <th>Requested Date</th>
                                        <th>From Branch</th>
                                        <th>Quantity</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>                                  
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($key + 1); ?></th>
                                            <td><?php echo e($item->product->productname); ?></td> 
                                            <td><?php echo e($item->created_at); ?></td>
                                            <td><?php echo e(\App\Models\Branch::where('id','=', $item->from_branch_id)->first()->name); ?></td> 
                                            <td><?php echo e($item->requestqty); ?></td> 
                                            <td>
                                                <?php if($item->status == "1"): ?>
                                                    <button class="btn btn-sm btn-success">Transferred</button>
                                                <?php else: ?>
                                                <a href='#' id='transferBtn' class='btn btn-sm btn-theme ms-1'  data-bs-toggle='modal' data-bs-target='#reqStockModal' >Transfer</a>
                                                <?php endif; ?>
                                                
                                                

                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                        </div> 
                </div>
                </div>

            </div>
        </div>
        </div>

    </section>

    <div class="modal fade" id="reqStockModal" tabindex="-1" aria-labelledby="reqStockModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="reqStockModalLabel">Product stock request</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="form-custom" id="stockReqForm">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="quantity" class="col-sm-3 control-label">Quantity</label>
                        <div class="col-sm-9">
                            <input type="number" name="quantity" class="form-control" id="quantity" required>
                            <input type="hidden" name="productid" class="form-control" id="productid">
                            <input type="hidden" name="stockid" class="form-control" id="stockid">
                            <input type="hidden" name="reqtobranchid" class="form-control" id="reqtobranchid">
                        </div>
                    </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary req-save-btn">Request</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('script'); ?>

<script>
    
    $(document).ready( function () {
        $('#example').DataTable();
    } );

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/user/stock/stockrequest.blade.php ENDPATH**/ ?>