<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>  <?php echo e(config('app.name')); ?> </title>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('styleResource/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('styleResource/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    

    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
    </style>
</head>
<body id="app-layout">
<nav class="navbar navbar-default navbar-static-top">

</nav>
    <style>
        .input-group-lg>.form-control, .input-group-lg>.input-group-addon, .input-group-lg>.input-group-btn>.btn{
            font-size: 15px;
        }
    </style>
    <div class="container">
        <div class="row">
            <div class="well col-md-5 center col-md-offset-3">

                <div class="panel panel-info">
                     
                     <?php if(Session::has('error')): ?>
                     <div class="alert alert-danger">
                       <?php echo e(Session::get('error')); ?>

                     </div>
                     <?php endif; ?>

                    <div class="panel-body">
                        
                        <div class="login-page">  
                            
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
                <div>Copyright © <?php echo date("Y"); ?> Next Link. All Rights Reserved.</div>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="<?php echo e(asset('styleResource/bower_components/jquery/dist/jquery.min.js')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('styleResource/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>">



<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
    $('#password').focusin(function(){
    $('form').addClass('up')
  });
  $('#password').focusout(function(){
    $('form').removeClass('up')
  });
  
  // Panda Eye move
  $(document).on( "mousemove", function( event ) {
    var dw = $(document).width() / 15;
    var dh = $(document).height() / 15;
    var x = event.pageX/ dw;
    var y = event.pageY/ dh;
    $('.eye-ball').css({
      width : x,
      height : y
    });
  });
  
  // validation
  
  
  $('.btn').click(function(){
    $('form').addClass('wrong-entry');
      setTimeout(function(){ 
         $('form').removeClass('wrong-entry');
       },3000 );
  });
  
  </script>
</body>
</html>
<?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/layouts/auth.blade.php ENDPATH**/ ?>