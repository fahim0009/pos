
<div class="box box-widget widget-user-2">
    <div class="widget-user-header">
        <h3 class="widget-user-username"><?php echo e($title); ?></h3>
        <?php if(isset($description)): ?>
        <h5 class="widget-user-desc table-responsive"><?php echo e($description); ?></h5>
        <?php endif; ?>
    </div>
    <div class="box-body table-responsive">
        <?php echo e($body); ?>

    </div>
</div>
<?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/components/widget.blade.php ENDPATH**/ ?>