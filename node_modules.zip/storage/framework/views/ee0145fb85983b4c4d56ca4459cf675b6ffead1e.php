
<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <div class="row">
        <div class="col-md-12">
            <div class="overview">
                <div class="alert alert-success h4"> You can add new admin from here</div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="box box-default box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title">Add System Admin</h3>
                    <!-- /.box-tools -->
                </div>

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="">
                        <div class="col-md-12">
                            <div class="ermsg"></div>

                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('success'); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(\Session::has('error')): ?>
                                <div class="alert alert-warning">
                                    <?php echo \Session::get('error'); ?>

                                </div>
                            <?php endif; ?>

                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('save_admin')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="row mb-3 form-group">
                                            <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Name')); ?></label>

                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3 form-group">
                                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                                            <div class="col-md-6">
                                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3 form-group">
                                            <label for="branch_id" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Branch')); ?></label>

                                            <div class="col-md-6">
                                                <select name="branch_id" id="branch_id" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php $__currentLoopData = \App\Models\Branch::where('status','1')->get();; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mb-3 form-group">
                                            <label for="role_id" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Role')); ?></label>

                                            <div class="col-md-6">
                                                <select name="role_id" id="role_id" class="form-control">
                                                    <option value="">Select</option>
                                                    <?php $__currentLoopData = \App\Models\Role::all();; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mb-3 form-group">
                                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                                            <div class="col-md-6">
                                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3 form-group">
                                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Confirm Password')); ?></label>

                                            <div class="col-md-6">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                            </div>
                                        </div>

                                        <div class="row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(__('Register')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box-body -->
            <!-- /.box -->
        </div>

        <script>
            $(function () {
                $('.select2').select2();

            });


            var url = "<?php echo e(URL::to('/admin/save-user')); ?>";

            function save_user_info() {
                if ($("#username").val() == "") {
                    alert("Please Provide the Name of the User");
                    return;
                }

                if ($("#email").val() == "") {
                    alert("Please Provide the Email of the User");
                    return;
                }


                if ($("#password").val() == "") {

                    alert("Please Provide the Password of the User");
                    return;
                }

                if ($("#branchdropdown").val() == "") {

                    alert("Please Provide the Branch of the User");
                    return;
                }

                data = {
                    name: $("#username").val(),
                    email: $("#email").val(),
                    branch: $("#branchdropdown").val(),
                    password: $("#password").val(),
                };
                $.ajax({
                    data: {
                        data: data
                    },
                    url: url,
                    type: 'POST',
                    beforeSend: function (request) {
                        return request.setRequestHeader('X-CSRF-Token', $("meta[name='csrf-token']").attr('content'));
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == "Duplicate") {
                            alert('Duplicate email found! please check.');

                        } else {
                            $(".ermsg").html(response.message);
                            $("#username").val("");
                            $("#email").val("");
                            $("#branchdropdown").val("");
                            $("#password").val("");
                        }

                    },
                    error: function (err) {
                        console.log(err);
                        alert("Something Went Wrong, Please check again");
                    }
                });
            }

            

            let helpersbranch =
                {
                    buildDropdown: function (result, table, emptyMessage) {
                        // Remove current options
                        table.html('');
                        // Add the empty option with the empty message
                        table.append('<option value="">' + emptyMessage + '</option>');
                        // Check result isnt empty
                        if (result != '') {
                            // Loop through each of the results and append the option to the table
                            $.each(result, function (k, v) {
                                if (v.branchstatus == 1)
                                    table.append('<option value="' + v.branchid + '">' + v.branchname + '</option>');

                            });
                        }
                    }
                }

            

            let helpersrole =
                {
                    buildDropdown: function (result, table, emptyMessage) {
                        // Remove current options
                        table.html('');
                        // Add the empty option with the empty message
                        table.append('<option value="">' + emptyMessage + '</option>');
                        // Check result isnt empty
                        if (result != '') {
                            // Loop through each of the results and append the option to the table
                            $.each(result, function (k, v) {
                                if (v.status == 1)
                                    table.append('<option value="' + v.id + '">' + v.name + '</option>');

                            });
                        }
                    }
                }

        </script>
<?php $__env->stopSection(); ?>


    
<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/admin/user/createadmin.blade.php ENDPATH**/ ?>