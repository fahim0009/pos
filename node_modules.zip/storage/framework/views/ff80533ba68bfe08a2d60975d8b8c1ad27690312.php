

<?php $__env->startSection('content'); ?>

<h2 class="text-blue">
    <i class="fa fa-money text-green" aria-hidden="true"></i> Stock Transfer Report
    <small class="text-aqua">All Information</small>
</h2>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
<hr class="alert-info">
<?php if(session('message')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
<?php
echo Session::put('message', '');
?>

<div class="row well">
    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('stockTransferReport.search')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-2">
            <label class="label label-primary">From </label>
            <input type="date" class="form-control" name="fromdate" required>
        </div>
        <div class="col-md-2">
            <label class="label label-primary">To </label>
            <input type="date" class="form-control" name="todate" value="<?php echo e(date('Y-m-d')); ?>" required>
        </div>
        

        <div class="col-md-2">
            <br>
            <button type="submit" class="btn btn-primary btn-sm">Search</button>
        </div>
    </form>
</div>
<div class="row">

    <div class="col-md-10">
        <div class="panel panel-primary">
            <div class="panel-heading"><i class="fa fa-navicon"></i> Summery</div>
            <p class="label label-info pull-right">
                Month: <span class="label label-warning">
                    <?php if(isset($month)): ?>
                        <?php
                            $today = Carbon\Carbon::create()->day(1)->month($month);
                            echo $today->format('F');
                        ?>
                    <?php else: ?>
                        <?php
                            $today = Carbon\Carbon::now();;
                            echo $today->format('F');

                        ?>
                    <?php endif; ?>
                    </span>
            </p>

            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        
                        
                        <?php $__env->startComponent('components.table'); ?>
                            <?php $__env->slot('tableID'); ?>
                                    purchaseTBL
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('head'); ?>
                                <th>Date</th>
                                <th>Partno</th>
                                <th>Product Name</th>
                                <th>From Branch</th>
                                <th>To Branch</th>
                                <th style="text-align:center">Quantity</th>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('body'); ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $frmbranch = \App\Models\Branch::where('id', $data->from_branch_id)->first()->name;
                                    $tobranch = \App\Models\Branch::where('id', $data->to_branch_id )->first()->name;
                                ?>
                                    <tr>
                                        <td><?php echo e($data->created_at); ?></td>
                                        <td><?php echo e($data->product->part_no); ?></td>
                                        <td><?php echo e($data->product->productname); ?></td>
                                        <td><?php echo e($frmbranch); ?></td>
                                        <td><?php echo e($tobranch); ?></td>
                                        <td style="text-align:center"><?php echo e($data->stocktransferqty); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>


                    </div>
                </div>
            </div>
        </div>

    </div>






    
</div>


<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('script'); ?>

<script>
$(document).ready(function () {
    
   $('#purchaseTBL').on( 'page.dt', function () {
    
   }).dataTable({
        "order": [[ 3, "asc" ]],
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'print',
                className: 'btn btn-md',
                exportOptions: {
                    columns: [0, 1, 2, 3,4,5,6,7]
                },
                title: 'Purchase Report'
                    
            },
            {
                extend: 'csv',
                className: 'btn btn-md',
                exportOptions: {
                    columns: [0, 1, 2, 3,4,5,6,7]
                },
                title: 'Purchase Report'
            },
            {
                extend: 'pdf',
                className: 'btn btn-md',
                exportOptions: {
                    columns: [0, 1, 2, 3,4,5,6,7]
                },
                title: 'Purchase Report'
            },
        ]
   });
});
</script>
 
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/admin/report/stocktransfer.blade.php ENDPATH**/ ?>