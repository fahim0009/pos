<table  id="<?php echo e($tableID); ?>" class="table table-hover table-responsive " width="100%">
    <thead>
    <?php if(isset($head)): ?>
        <tr>
            <?php echo e($head); ?>

        </tr>
      <?php endif; ?>
    </thead>
    <tbody>
    <?php if(isset($body)): ?>
            <?php echo e($body); ?>

     <?php endif; ?>

    </tbody>
    <tfoot>
    <?php if(isset($footer)): ?>
        <?php echo e($footer); ?>

    <?php endif; ?>
    </tfoot>

</table><?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/components/table.blade.php ENDPATH**/ ?>