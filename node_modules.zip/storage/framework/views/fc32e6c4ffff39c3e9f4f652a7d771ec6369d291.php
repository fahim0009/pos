


<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <?php
    echo Session::put('message', '');
    ?>
    <?php if(session('info')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <?php
    echo Session::put('info', '');
    ?>
  <div class="ermsg"></div>

  <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <?php echo \Session::get('success'); ?>

      </div>
  <?php endif; ?>

  <?php if(\Session::has('error')): ?>
      <div class="alert alert-warning">
          <?php echo \Session::get('error'); ?>

      </div>
  <?php endif; ?>
    <div class="row">
        <div class="col-md-6">
            <?php $__env->startComponent('components.widget'); ?>
                <?php $__env->slot('title'); ?>
                    System User
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('description'); ?>
                    System User Information
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('body'); ?>
                    <?php $__env->startComponent('components.table'); ?>
                        <?php $__env->slot('tableID'); ?>
                            userTBL
                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('head'); ?>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Branch</th>
                            <th>Role</th>
                            <th><i class=""></i> Action</th>
                        <?php $__env->endSlot(); ?>
                        
                        <?php $__env->slot('body'); ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td><?php echo e(\App\Models\Branch::where('id',$data->branch_id)->first()->name); ?></td>
                                    <td><?php echo e($data->role->name); ?></td>
                                    <td>
                                        <span class="btn btn-success btn-sm editThis" id="editThis" vid="<?php echo e($data->id); ?>" name="<?php echo e($data->name); ?>" email="<?php echo e($data->email); ?>" branch_id="<?php echo e($data->branch_id); ?>" role_id="<?php echo e($data->role_id); ?>"> <i class='fa fa-pencil'></i> Edit </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
        <div class="col-md-6">
            <?php $__env->startComponent('components.widget'); ?>
                <?php $__env->slot('title'); ?>
                    User Information
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('description'); ?>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('body'); ?>
                    <hr/>

                    <div class="col-sm-12" id="editDiv">
                        <form class="form-horizontal" action="<?php echo e(route('update_user')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                        
                            <div class="form-group">
                                <label for="name" class="col-sm-3 control-label">Name<span class="text-danger">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" class="form-control" id="name" required>
                                    <input type="hidden" name="userid" class="form-control" id="userid" required>
                                </div>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback text-danger" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-sm-3 control-label">Email</label>
                                <div class="col-sm-9">
                                    <input type="email" name="email" class="form-control" id="email" required>
                                </div>
                                <?php if($errors->has('vendoremail')): ?>
                                    <span class="invalid-feedback text-danger" role="alert">
                                    <strong><?php echo e($errors->first('vendoremail')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group">
                                <label for="branch_id" class="col-sm-3 control-label">Branch</label>
                                <div class="col-sm-9">
                                    <select name="branch_id" class="form-control" id="branch_id">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = \App\Models\Branch::where('status','1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="role_id" class="col-sm-3 control-label">Role</label>
                                <div class="col-sm-9">
                                    <select name="role_id" id="role_id" class="form-control">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = \App\Models\Role::all();; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password" class="col-sm-3 control-label">Password<span class="text-danger">*</span></label>
                                <div class="col-sm-9">
                                    <input type="password" name="password" class="form-control" id="password">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="col-sm-3 control-label"></label>
                                <div class="col-sm-9">
                                    <button type="submit" class="btn btn-primary text-center"><i class="fa fa-save"></i> Update</button>
                                    <input type="button" class="btn btn-warning text-center" id="FormCloseBtn" value="Close">
                                </div>
                            </div>
                            


                        </form>
                    </div>
                <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
        
    </div>


 
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('script'); ?>
<script>
    function save_user_info() {
        let username = $("#username").val();

        let branchid = $("#branchdropdown").val();
        let categoryid = $("#categorydropdown").val();
        let password = $("#password").val();

        if (username == "") {
            alert("Please Provide the Username of The User");
            return;
        }
        if (branchid == "") {
            alert("Please Provide the Branch Name");
            return;
        }
        if (categoryid == "") {
            alert("Please Provide the Category");
            return;
        } else {
            let data = {
                id: dataToPush[row].id,
                username: username,
                password: password,
                branchid: branchid,
                categoryid: categoryid

            };
            $.ajax({
                data: {data: data},
                url: '/update-user-info',
                type: 'POST',
                beforeSend: function (request) {
                    return request.setRequestHeader('X-CSRF-Token', $("meta[name='csrf-token']").attr('content'));
                },
                success: function (response) {
                    if (response == "Duplicate") {
                        alert('Duplicate username found! please check.');

                    } else {
                        showSnakBar();
                        window.setTimeout(function () {
                            location.reload();
                        }, 1500);
                    }
                },
                error: function (err) {
                    console.log(err);
                    alert("Something Went Wrong, Please check again");
                }
            });
        }
    }


</script>
<script>
    $(function () {
        $('.select2').select2();
        $(".show_password"). prop("checked", false);
        function getFormattedDate(date) {
            let data = new Date(date);
            let year = data.getFullYear();
            let month = (1 + data.getMonth()).toString().padStart(2, '0');
            let day = data.getDate().toString().padStart(2, '0');

            return day + '/' + month + '/' + +year;
        }

        let logTBL = $('#logTBL').DataTable({
            'paging': true,
            'lengthChange': true,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': true
        });
        let invoiceTBL = $('#invoiceTBL').DataTable({
            'paging': true,
            'lengthChange': true,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': true
        });
        


    });
</script>

<script>
    $(document).ready(function () {

        
        
        $("#editDiv").hide();
        $("#FormCloseBtn").click(function(){
            $("#editDiv").hide();
        });


        // header for csrf-token is must in laravel
        $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });
        // 




        // return stock
        $("#userTBL").on('click','#editThis', function(){
            $("#editDiv").show();

            id = $(this).attr('vid');
            branch_id = $(this).attr('branch_id');
            role_id = $(this).attr('role_id');
            name = $(this).attr('name');
            email = $(this).attr('email');

            $('#userid').val(id);
            $('#branch_id').val(branch_id);
            $('#role_id').val(role_id);
            $('#name').val(name);
            $('#email').val(email);
                
            });
        // return stock end


    });  
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wokfirec/public_html/pos-mentosoftware-co-uk/resources/views/admin/user/manageuser.blade.php ENDPATH**/ ?>