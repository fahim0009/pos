<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="<?php echo e(asset('admin/js/everythingJS.js')); ?>"></script>
    <!-- Font Awesome -->
    <link rel="shortcut icon" href="#">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/all-skins.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/select2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/dataTables.bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/daterangepicker.css')); ?>">
    <!-- DataTables -->
    <style src="<?php echo e(asset('admin/css')); ?>/buttons.dataTables.min.css"></style>
    
    
    <script src="<?php echo e(asset('admin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/gijgo.min.js')); ?>" type="text/javascript"></script>
    <link href="<?php echo e(asset('admin/css/gijgo.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Google Font -->

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <header class="main-header">
        <!-- Logo -->
        <a href="#" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->

            <span class="logo-lg">
                        <img src="<?php echo e(asset('admin/demo.png')); ?>" width="32px" height="32px"><?php echo e(config('app.name')); ?>

                    </span>
                    
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-fixed-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i
                                    class="fa fa-user-circle-o"></i>
                                    <?php echo e(Auth::user()->branch->name); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li class="user-header" style="height: auto">
                                <img src="<?php echo e(asset('admin/demo.png')); ?>" class="img-circle"
                                     alt="User Image">
                            </li>
                            <li>
                                <p style="padding-left:15px;">
                                    Hello Name. Hope You Have Saved Your Work before Signing Out.
                                </p>
                            </li>
                            <!-- Menu Body -->
                        
                        
                        
                        <!-- Menu Footer-->
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="#" class="btn btn-success btn-flat dropdown-item"><i
                                                class="fa fa-user-circle-o"></i> Profile</a>
                                </div>
                                <div class="pull-right">
                                    <a class="btn btn-danger btn-flat dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"></i> <?php echo e(__('Sign out')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                          style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class=" main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <h4 style="color:white;font-size:11px" class="text-center"><?php echo e(Auth::user()->branch->name); ?></h4>
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo e(asset('admin/demo.png')); ?>" class="img-circle"
                         alt="User Image">
                </div>
                <div class="pull-left info">
                    <p>Name :<?php echo e(Auth::user()->name); ?> </p>
                    <small><?php echo e(Auth::user()->role->name); ?></small>
                </div>
            </div>
            <ul class="sidebar-menu" data-widget="tree">
                <li class="<?php echo e((request()->is('admin/home')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(URL::to('/home')); ?>">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>
                
                
                
                
                
                    <li class="treeview <?php echo e((request()->is('admin/add-product')) ? 'active' : ''); ?><?php echo e((request()->is('admin/manage-product')) ? 'active' : ''); ?><?php echo e((request()->is('admin/product-category')) ? 'active' : ''); ?><?php echo e((request()->is('admin/product-brand')) ? 'active' : ''); ?><?php echo e((request()->is('admin/product-group')) ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-files-o"></i>
                            <span> Products</span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i></span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Auth::user()->type == '1' && in_array('1', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('1', json_decode(Auth::user()->role->permission))): ?>
                                <li class="<?php echo e((request()->is('admin/add-product')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.addproduct')); ?>"><i class="fa fa-clone"></i> Add New Product</a> </li>
                            <?php endif; ?>

                            <?php if(Auth::user()->type == '1' && in_array('20', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('20', json_decode(Auth::user()->role->permission))): ?>
                                <li class="<?php echo e((request()->is('admin/manage-product')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.manage_product')); ?>"><i class="fa fa-leaf"></i> Manage product</a> </li>
                            <?php endif; ?>

                                <li class="<?php echo e((request()->is('admin/product-category')) ? 'active' : ''); ?>"><a href="<?php echo e(route('view_product_category')); ?>"><i class="fa fa-credit-card"></i>Code</a></li>
                                <li class="<?php echo e((request()->is('admin/product-brand')) ? 'active' : ''); ?>"><a href="<?php echo e(route('view_product_brand')); ?>"><i class="fa fa-credit-card"></i>Brand</a></li>
                                <li class="<?php echo e((request()->is('admin/product-group')) ? 'active' : ''); ?>"><a href="<?php echo e(route('view_product_group')); ?>"><i class="fa fa-credit-card"></i>Group</a> </li>
                            
                                
                        </ul>
                    </li>


                    <li class="treeview <?php echo e((request()->is('admin/add-stock')) ? 'active' : ''); ?> <?php echo e((request()->is('admin/manage-stock')) ? 'active' : ''); ?> <?php echo e((request()->is('admin/product-purchase-history')) ? 'active' : ''); ?> <?php echo e((request()->is('admin/stock-transfer-request')) ? 'active' : ''); ?> <?php echo e((request()->is('admin/stock-transfer-history')) ? 'active' : ''); ?> <?php echo e((request()->is('admin/stock-return-history')) ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-clipboard"></i>
                            <span>Stocks</span>
                            <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i></span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Auth::user()->type == '1' && in_array('5', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('5', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/add-stock')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.addstock')); ?>"><i class="fa fa-plus"></i>Purchase </a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->type == '1' && in_array('21', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('21', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/manage-stock')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.managestock')); ?>"><i class="fa fa-truck"></i> Stock List</a></li>
                            <?php endif; ?>

                            <?php if(Auth::user()->type == '1' && in_array('5', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('5', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/product-purchase-history')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.product.purchasehistory')); ?>"><i class="fa fa-history"></i>Purchase History</a></li>
                            <?php endif; ?>

                            <?php if(Auth::user()->type == '1' && in_array('7', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('7', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/stock-transfer-request')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.stock.transferrequest')); ?>"><i class="fa fa-history"></i>Stock Transfer Request</a></li>
                            <?php endif; ?>

                            <?php if(Auth::user()->type == '1' && in_array('18', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('18', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/stock-transfer-history')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.stock.transferhistory')); ?>"><i class="fa fa-history"></i>Transferred History</a></li>
                            <?php endif; ?>

                            <?php if(Auth::user()->type == '1' && in_array('19', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('19', json_decode(Auth::user()->role->permission))): ?>
                            <li class="<?php echo e((request()->is('admin/stock-return-history')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.stockReturnHistory')); ?>"><i class="fa fa-undo"></i>Returned History</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    <?php if(Auth::user()->type == '1' && in_array('14', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('14', json_decode(Auth::user()->role->permission))): ?>
                    <li class="<?php echo e((request()->is('admin/vendor/add')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.addvendor')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Supplier</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == '1' && in_array('15', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('15', json_decode(Auth::user()->role->permission))): ?>
                    <li class="<?php echo e((request()->is('admin/customers')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.addcustomer')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Customer</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == '1' && in_array('16', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('16', json_decode(Auth::user()->role->permission))): ?>
                    <li class="<?php echo e((request()->is('admin/branch')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('view_branch')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Branch</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>
                    <?php endif; ?>


                
                
                    <?php if(Auth::user()->type == '1' && in_array('17', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('17', json_decode(Auth::user()->role->permission))): ?>
                    <li class="treeview <?php echo e((request()->is('admin/all-sellsinvoice')) ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-user"></i> <span>Sales</span><span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i></span>
                        </a>
                        <ul class="treeview-menu">
                                <li><a href="<?php echo e(route('sales')); ?>"><i class="fa fa-adjust"></i> Sales</a></li>
                                <li class="<?php echo e((request()->is('admin/all-sellsinvoice')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.allsellinvoice')); ?>"><i class="fa fa-adjust"></i> Manage Sales</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == '1' && in_array('22', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('22', json_decode(Auth::user()->role->permission))): ?>
                    <li class="<?php echo e((request()->is('admin/payment-method')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('view_payment_method')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Payment Method</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->type == '1' && in_array('23', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('23', json_decode(Auth::user()->role->permission))): ?>
                    <li class="<?php echo e((request()->is('admin/getreport-title')) ? 'active' : ''); ?><?php echo e((request()->is('admin/sales-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/sales-return-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/quotation-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/delivery-note-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/purchase-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/purchase-return-report')) ? 'active' : ''); ?><?php echo e((request()->is('admin/stock-transfer-report')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('report')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Report</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>
                    <?php endif; ?>


                    <?php if(Auth::user()->type == '1' && in_array('8', json_decode(Auth::user()->role->permission)) || Auth::user()->type == '0' && in_array('8', json_decode(Auth::user()->role->permission))): ?>
                    <li class="treeview <?php echo e((request()->is('admin/role*')) ? 'active' : ''); ?><?php echo e((request()->is('admin/manage-user')) ? 'active' : ''); ?><?php echo e((request()->is('admin/create-user')) ? 'active' : ''); ?><?php echo e((request()->is('admin/manage-admin')) ? 'active' : ''); ?><?php echo e((request()->is('admin/create-admin')) ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-users"></i>
                            <span>System Users</span>
                            <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i></span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php echo e((request()->is('admin/create-user')) ? 'active' : ''); ?>"><a href="<?php echo e(route('create_user')); ?>"><i class="fa fa-plus"></i> Add New User</a>
                            </li>
                            <li class="<?php echo e((request()->is('admin/manage-user')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_user')); ?>"><i class="fa fa-adjust"></i>Manage User</a>
                            </li>
                            <li class="<?php echo e((request()->is('admin/create-admin')) ? 'active' : ''); ?>"><a href="<?php echo e(route('create_admin')); ?>"><i class="fa fa-plus"></i> Add New Admin</a>
                            
                            <li class="<?php echo e((request()->is('admin/manage-admin')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_admin')); ?>"><i class="fa fa-adjust"></i>Manage Admin</a>
                            </li>
                            <li class="<?php echo e((request()->is('admin/role*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.role')); ?>"><i class="fa fa-adjust"></i>Manage Role</a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <li class="<?php echo e((request()->is('admin/switch_branch')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('switch_branch')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Swich Branch</span>
                            <span class="pull-right-container"> </span>
                        </a>
                    </li>


                    
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header pageheader">
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"></li>
            </ol>
        </section>
        <!-- Main content -->
        <div id="snackbar">Data updated successfully.</div>
        <section class="content">
            
            
            
                
            <br>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer fixed-bottom">
        <div class="container-fluid">
            <div class="offset-md-3 col-md-9">
                <div class="pull-right hidden-xs">
                    <b>Version:</b> 1.1.0
                </div>
                <strong>Copyright &copy; </strong>Next Link Ltd All rights reserved.
            </div>
        </div>
    </footer>
    <!-- Add the sidebar's background. This must be placed
    immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<script src="<?php echo e(asset('admin/js')); ?>/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('admin/js')); ?>/buttons.print.min.js"></script>
<script src="<?php echo e(asset('admin/js')); ?>/pdfmake.min.js"></script>
<script src="<?php echo e(asset('admin/js')); ?>/vfs_fonts.js"></script>
<script src="<?php echo e(asset('admin/js')); ?>/buttons.html5.min.js"></script>

<script>
    function showSnakBar(msg = null) {
        var x = document.getElementById("snackbar")
        x.className = "show";
        if (msg) {
            x.innerText = msg
        }
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }
</script>
<script>
    // page schroll top
    function pagetop() {
        window.scrollTo({
            top: 100,
            behavior: 'smooth',
        });
    }
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel9\new\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>