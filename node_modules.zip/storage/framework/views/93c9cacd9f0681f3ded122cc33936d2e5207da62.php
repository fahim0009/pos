

<?php $__env->startSection('content'); ?>
<style>
    .px-2 {
    margin-top: 2px !important;
    margin-bottom: 2px !important;
    }

    .block{
        width:180px; 
        }
</style>

<?php if(Auth::user()->id != 1): ?>
    
<div class="row">
    <div class="col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading"><i class="fa fa-navicon"></i> Switch Branch</div>
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo \Session::get('success'); ?>

                </div>
            <?php endif; ?>
            <div class="panel-body">
                <form class="form-horizontal" action="<?php echo e(route('switch_branch_store')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-8">
                        <label class="label label-primary">Branch</label>
                        <select class="form-control select2" name="branch_id">
                            <option value="">Select Branch..</option>
                            <?php
                            
                                $branches = json_decode(Auth::user()->branchaccess, true);
                            ?>

                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $branchNames = \App\Models\Branch::where('status','1')->where('id', $item)->get();
                                ?>
                                <?php $__currentLoopData = $branchNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branchName->id); ?>"><?php echo e($branchName->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                        </select>
                    </div>

                    <div class="col-md-4">
                        <br>
                        <button type="submit" class="btn btn-primary btn-sm block">Switch</button>
                    </div>


                </div>
                
            </form>
            </div>
        </div>

    </div>
</div>

<?php endif; ?>

<?php if(Auth::user()->id == 1): ?>
<div class="row">
    <div class="col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading"><i class="fa fa-navicon"></i> Switch Branch</div>

            <div class="panel-body">

                
                

                <div class="row">
                    <div class="col-md-8">
                        <label class="label label-primary">Branch</label>
                        <select class="form-control select2" name="branch_id">
                            <option value="">Select Branch..</option>
                                <?php
                                    $branchNames = \App\Models\Branch::where('status','1')->get();
                                ?>
                                <?php $__currentLoopData = $branchNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branchName->id); ?>"><?php echo e($branchName->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                        </select>
                    </div>

                    <div class="col-md-4">
                        <br>
                        <button type="submit" class="btn btn-primary btn-sm block">Switch</button>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

<?php endif; ?>


<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('script'); ?>


 
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel9\new\resources\views/admin/user/switch.blade.php ENDPATH**/ ?>